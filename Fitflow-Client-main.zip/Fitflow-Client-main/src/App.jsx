

import React, { useEffect, useState } from "react";
import { Routes, Route, useLocation, useNavigate } from "react-router-dom";
import BackToTopButton from "./components/BackToTopButton";
import FeedbackButton from "./components/FeedbackButton";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Community from "./components/Community";
import Avatar from "./components/Avatar";
import Modules from "./components/Modules";
import Progress from "./components/Progress";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import LoginModal from "./components/LoginModal";
import SignupModal from "./components/SignupModal";
import FullCommunity from "./components/FullCommunity";
import VisualDashboard from "./components/VisualDashboard";
import FormAccuracy from "./components/FormAccuracy";
import ChatBox from "./components/ChatBox";


// ✅ Avatar-specific content pages
import CricketAvatar from "./components/CricketAvatar";
import GymAvatar from "./components/GymAvatar";
import BasketballAvatar from "./components/BasketballAvatar";

// ✅ Module-specific pages
import CricketModule from "./components/CricketModule";
import FootballModule from "./components/FootballModule";
import GymTrainingModule from "./components/GymTrainingModule";
import TableTennis from "./components/TableTennis";

import "./style.css";

const App = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");

  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem("sportsUser"));
    const loginState = localStorage.getItem("isLoggedIn");
    if (savedUser && loginState === "true") {
      setIsLoggedIn(true);
      setUserName(savedUser.name);
    }
  }, []);

  const logoutUser = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
    setUserName("");
    alert("You have been logged out.");
  };

  const handleLoginSuccess = (name) => {
    setUserName(name);
    setIsLoggedIn(true);
    navigate("/");
  };

  const handleSignupSuccess = (name) => {
    setUserName(name);
    setIsLoggedIn(true);
    navigate("/");
  };

  return (
    <>
      <Header
        isLoggedIn={isLoggedIn}
        userName={userName}
        onLogout={logoutUser}
        onLogin={() => navigate("/login")}
        onSignup={() => navigate("/signup")}
      />

      <main>
        <Routes location={location}>
          {/* Homepage Routes */}
          <Route
            path="/"
            element={
              <>
                <Hero />
                <Community />
                <Avatar />
                <Modules />
                <Progress />
                <CTA />
              </>
            }
          />

          {/* Modal Routes */}
          <Route
            path="/login"
            element={
              <LoginModal
                onClose={() => navigate("/")}
                onLogin={handleLoginSuccess}
              />
            }
          />
          <Route
            path="/signup"
            element={
              <SignupModal
                onClose={() => navigate("/")}
                onSignup={handleSignupSuccess}
              />
            }
          />

          {/* Community Page */}
          <Route path="/community" element={<FullCommunity />} />

          {/* Avatar-specific pages */}
          <Route path="/avatar/cricket" element={<CricketAvatar />} />
          <Route path="/avatar/gym" element={<GymAvatar />} />
          <Route path="/avatar/basketball" element={<BasketballAvatar />} />

          {/* Module-specific pages */}
          <Route path="/modules/cricket" element={<CricketModule />} />
          <Route path="/modules/football" element={<FootballModule />} />
          <Route path="/modules/gym" element={<GymTrainingModule />} />
          <Route path="/modules/table-tennis" element={<TableTennis />} />

          <Route path="/dashboard" element={<VisualDashboard />} />
          <Route path="/form-accuracy" element={<FormAccuracy />} />

        </Routes>
      </main>

      <Footer />
      <BackToTopButton />
      <FeedbackButton />
      <ChatBox />
    </>
  );
};

export default App;




// import React, { useEffect, useState } from "react";
// import {
//   Routes,
//   Route,
//   useNavigate,
//   Navigate,
// } from "react-router-dom";
// import BackToTopButton from "./components/BackToTopButton";
// import FeedbackButton from "./components/FeedbackButton";
// import Header from "./components/Header";
// import Hero from "./components/Hero";
// import Community from "./components/Community";
// import Avatar from "./components/Avatar";
// import Modules from "./components/Modules";
// import Progress from "./components/Progress";
// import CTA from "./components/CTA";
// import Footer from "./components/Footer";
// import LoginModal from "./components/LoginModal";
// import SignupModal from "./components/SignupModal";
// import Dashboard from "./components/Dashboard";
// import "./style.css";

// // Home component
// const Home = ({
//   isLoggedIn,
//   userName,
//   onLogout,
//   showLogin,
//   setShowLogin,
//   showSignup,
//   setShowSignup,
//   handleLoginSuccess,
//   handleSignupSuccess,
// }) => {
//   return (
//     <div>
//       <Header
//         isLoggedIn={isLoggedIn}
//         userName={userName}
//         onLogout={onLogout}
//         onLogin={() => setShowLogin(true)}
//         onSignup={() => setShowSignup(true)}
//       />
//       <main>
//         <Hero />
//         <Community />
//         <Avatar />
//         <Modules />
//         <Progress />
//         <CTA />
//       </main>
//       <Footer />
//       <BackToTopButton />
//       <FeedbackButton />

//       {showLogin && (
//         <LoginModal
//           onClose={() => setShowLogin(false)}
//           onLogin={handleLoginSuccess}
//         />
//       )}
//       {showSignup && (
//         <SignupModal
//           onClose={() => setShowSignup(false)}
//           onSignup={handleSignupSuccess}
//         />
//       )}
//     </div>
//   );
// };

// // App component
// const App = () => {
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [userName, setUserName] = useState("");
//   const [showLogin, setShowLogin] = useState(false);
//   const [showSignup, setShowSignup] = useState(false);
//   const navigate = useNavigate();

//   useEffect(() => {
//     try {
//       const savedUser = JSON.parse(localStorage.getItem("sportsUser"));
//       const loginState = localStorage.getItem("isLoggedIn");
//       if (savedUser && loginState === "true") {
//         setIsLoggedIn(true);
//         setUserName(savedUser.name || savedUser.username);
//       }
//     } catch (e) {
//       console.error("Failed to parse saved user:", e);
//     }
//   }, []);

//   const logoutUser = () => {
//     localStorage.removeItem("isLoggedIn");
//     localStorage.removeItem("sportsUser");
//     setIsLoggedIn(false);
//     setUserName("");
//     alert("You have been logged out.");
//   };

//   const handleLoginSuccess = (name) => {
//     const user = { name };
//     localStorage.setItem("sportsUser", JSON.stringify(user));
//     localStorage.setItem("isLoggedIn", "true");
//     setUserName(name);
//     setIsLoggedIn(true);
//     setShowLogin(false);
//     navigate("/dashboard");
//   };

//   const handleSignupSuccess = (name) => {
//     const user = { name };
//     localStorage.setItem("sportsUser", JSON.stringify(user));
//     localStorage.setItem("isLoggedIn", "true");
//     setUserName(name);
//     setIsLoggedIn(true);
//     setShowSignup(false);
//     navigate("/dashboard");
//   };

//   return (
//     <Routes>
//       <Route
//         path="/"
//         element={
//           <Home
//             isLoggedIn={isLoggedIn}
//             userName={userName}
//             onLogout={logoutUser}
//             showLogin={showLogin}
//             setShowLogin={setShowLogin}
//             showSignup={showSignup}
//             setShowSignup={setShowSignup}
//             handleLoginSuccess={handleLoginSuccess}
//             handleSignupSuccess={handleSignupSuccess}
//           />
//         }
//       />
//       <Route
//         path="/dashboard"
//         element={
//           isLoggedIn ? (
//             <Dashboard userName={userName} />
//           ) : (
//             <Navigate to="/" replace />
//           )
//         }
//       />
//       {/* Optional: handle undefined routes */}
//       <Route path="*" element={<Navigate to="/" replace />} />
//     </Routes>
//   );
// };

// export default App; 
