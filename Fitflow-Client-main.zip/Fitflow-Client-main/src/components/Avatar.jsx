import React from "react";
import { Link } from "react-router-dom";

const Avatar = () => (
  <section className="avatar-section">
    <div className="avatar-content">
      <h2>Interactive Avatars for Every Sport</h2>
      <p>Watch and learn with realistic avatar tutorials for sports like cricket, gym, basketball, and more.</p>
      <div className="avatar-grid">
        <Link to="/avatar/cricket" className="avatar-box">
          <img src="https://cdn-icons-png.flaticon.com/512/2965/2965875.png" alt="Cricket" />
          <h4>Cricket Batting Form</h4>
        </Link>
        <Link to="/avatar/gym" className="avatar-box">
          <img src="https://cdn-icons-png.flaticon.com/512/924/924915.png" alt="Gym" />
          <h4>Proper Gym Posture</h4>
        </Link>
        <Link to="/avatar/basketball" className="avatar-box">
          <img src="https://cdn-icons-png.flaticon.com/512/861/861512.png" alt="Basketball" />
          <h4>Dribble & Shoot Basics</h4>
        </Link>
      </div>
    </div>
  </section>
);

export default Avatar;
