import React, { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, Legend } from "chart.js";

ChartJS.register(ArcElement, ChartTooltip, Legend);

// Define sports and initial feedback per sport
const sports = ["Cricket", "Football", "Gym", "Table Tennis"];
const initialData = {
  Cricket: [
    { skill: "Batting Form", result: "Excellent", score: 92 },
    { skill: "Bowling Posture", result: "Good", score: 75 },
  ],
  Football: [
    { skill: "Kicking Technique", result: "Average", score: 60 },
    { skill: "Running Form", result: "Good", score: 78 },
  ],
  Gym: [
    { skill: "Squat Depth", result: "Excellent", score: 90 },
    { skill: "Shoulder Press", result: "Average", score: 68 },
  ],
  "Table Tennis": [
    { skill: "Serve Motion", result: "Good", score: 72 },
    { skill: "Backhand Technique", result: "Poor", score: 45 },
  ],
};

const FormAccuracy = () => {
  const [activeSport, setActiveSport] = useState("Cricket");
  const [feedbackData, setFeedbackData] = useState(initialData);
  const [newSkill, setNewSkill] = useState("");
  const [newScore, setNewScore] = useState("");

  const handleAddFeedback = () => {
    if (!newSkill || !newScore) return;

    const score = parseInt(newScore);
    const result =
      score >= 85 ? "Excellent" : score >= 70 ? "Good" : score >= 50 ? "Average" : "Poor";

    const updated = {
      ...feedbackData,
      [activeSport]: [
        ...feedbackData[activeSport],
        { skill: newSkill, result, score },
      ],
    };

    setFeedbackData(updated);
    setNewSkill("");
    setNewScore("");
  };

  const currentFeedback = feedbackData[activeSport];

  const doughnutData = {
    labels: ["Excellent", "Good", "Average", "Poor"],
    datasets: [
      {
        data: [
          currentFeedback.filter((f) => f.result === "Excellent").length,
          currentFeedback.filter((f) => f.result === "Good").length,
          currentFeedback.filter((f) => f.result === "Average").length,
          currentFeedback.filter((f) => f.result === "Poor").length,
        ],
        backgroundColor: ["#5bc0be", "#3a506b", "#1c2541", "#ff6b6b"],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="page-container" style={{ padding: "2rem", color: "#fff" }}>
      <h1 style={{ color: "#5bc0be" }}>Form Accuracy Dashboard</h1>
      <p>AI-based form feedback for each sport. Switch tabs to view.</p>

      {/* Sport Tabs */}
      <div style={{ display: "flex", gap: "1rem", margin: "1rem 0", flexWrap: "wrap" }}>
        {sports.map((sport) => (
          <button
            key={sport}
            onClick={() => setActiveSport(sport)}
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: activeSport === sport ? "#5bc0be" : "#3a506b",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
          >
            {sport}
          </button>
        ))}
      </div>

      {/* Feedback Cards */}
      <div style={{ margin: "2rem 0" }}>
        {currentFeedback.map((item, index) => (
          <div
            key={index}
            style={{
              backgroundColor: "#1c2541",
              padding: "1rem",
              borderRadius: "8px",
              marginBottom: "1rem",
            }}
          >
            <h3>{item.skill}</h3>
            <p>
              Result: <strong>{item.result}</strong> — Score:{" "}
              <strong>{item.score}%</strong>
            </p>
            <div
              style={{
                backgroundColor: "#3a506b",
                borderRadius: "8px",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  width: `${item.score}%`,
                  backgroundColor: "#5bc0be",
                  color: "#fff",
                  padding: "0.4rem",
                  textAlign: "center",
                }}
              >
                {item.score}%
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bar Chart */}
      <div style={{ height: 300, marginBottom: "3rem" }}>
        <ResponsiveContainer>
          <BarChart data={currentFeedback}>
            <CartesianGrid strokeDasharray="3 3" stroke="#3a506b" />
            <XAxis dataKey="skill" stroke="#ffffff" />
            <YAxis stroke="#ffffff" />
            <Tooltip />
            <Bar dataKey="score" fill="#5bc0be" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Add New Evaluation */}
      <div style={{ marginBottom: "3rem" }}>
        <h3>Add Real-Time Feedback for {activeSport}</h3>
        <input
          type="text"
          placeholder="Skill name"
          value={newSkill}
          onChange={(e) => setNewSkill(e.target.value)}
          style={{
            padding: "0.5rem",
            marginRight: "0.5rem",
            borderRadius: "4px",
            border: "1px solid #ccc",
            width: "150px",
          }}
        />
        <input
          type="number"
          placeholder="Score %"
          value={newScore}
          onChange={(e) => setNewScore(e.target.value)}
          style={{
            padding: "0.5rem",
            marginRight: "0.5rem",
            borderRadius: "4px",
            border: "1px solid #ccc",
            width: "100px",
          }}
        />
        <button
          onClick={handleAddFeedback}
          style={{
            padding: "0.5rem 1rem",
            backgroundColor: "#5bc0be",
            color: "#fff",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
          }}
        >
          Add Feedback
        </button>
      </div>

      {/* Doughnut Chart */}
      <div style={{ width: "300px", margin: "0 auto" }}>
        <h3 style={{ textAlign: "center", marginBottom: "1rem" }}>
          {activeSport} Summary
        </h3>
        <Doughnut data={doughnutData} />
      </div>
    </div>
  );
};

export default FormAccuracy;
