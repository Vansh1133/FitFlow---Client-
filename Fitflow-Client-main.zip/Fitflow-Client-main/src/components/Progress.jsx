import React from "react";
import { Link } from "react-router-dom";

const Progress = () => (
  <section className="progress-section" id="progress">
    <div className="progress-content">
      <h2>Track Your Progress</h2>
      <p>Use dashboards, performance scores, and AI feedback.</p>

      <div className="progress-highlights">
        <Link to="/dashboard" className="progress-highlight">
          <i className="fas fa-chart-line"></i>
          <p>
            <strong>Visual Dashboards</strong><br />
            Monitor your learning progress.
          </p>
        </Link>

        <Link to="/form-accuracy" className="progress-highlight">
          <i className="fas fa-bullseye"></i>
          <p>
            <strong>Form Accuracy</strong><br />
            Get real-time AI-based technique feedback.
          </p>
        </Link>
      </div>
    </div>
  </section>
);

export default Progress;
