import React from "react";

const Footer = () => (
  <>
    <footer className="footer">
      <div className="footer-brand">
        <img src="https://i.pinimg.com/736x/ff/ea/ef/ffeaefac4eb3c25bd0aeaefa159cf60e.jpg" alt="Logo" />
        <h3>Sports Management</h3>
        <p>AI-powered platform for mastering sports techniques and training at all levels.</p>
      </div>
      <div className="footer-links">
        <h4>Platform</h4>
        <a href="#modules">Modules</a>
        <a href="#">Pricing</a>
        <a href="#">Support</a>
        <a href="#">API</a>
      </div>
      <div className="footer-links">
        <h4>Resources</h4>
        <a href="#">Terms of Use</a>
        <a href="#">Privacy Policy</a>
        <a href="#">Contact</a>
      </div>
    </footer>
    <div className="footer-bottom">
      <p>&copy; 2025 Sports Management. All rights reserved.</p>
    </div>
  </>
);

export default Footer;
