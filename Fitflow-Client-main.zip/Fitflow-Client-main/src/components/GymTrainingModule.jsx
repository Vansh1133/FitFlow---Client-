import React from "react";

const GymTrainingModule = () => (
  <section className="module-container">
    <div className="module-image-container">
      <img
        src="https://i.pinimg.com/736x/ef/f9/9b/eff99b80a488117d655987a5f0365ed3.jpg"
        alt="Gym Training"
        className="module-image"
      />
    </div>

    <div className="module-content">
      <h2>Gym Training Module</h2>
      <p>
        This module guides you through proper gym techniques to build muscle,
        improve endurance, and maintain physical health. Learn how to perform
        exercises with correct form, breathing techniques, and injury
        prevention strategies to make your workouts safe and effective.
      </p>
      <ul>
        <li>✅ Learn proper form for squats, deadlifts, and bench press</li>
        <li>💡 Understand warm-up and cool-down routines</li>
        <li>⚙️ Focus on muscle groups with split training schedules</li>
        <li>📏 Monitor progress with reps, sets, and load tracking</li>
        <li>⚠️ Avoid common gym mistakes and prevent injury</li>
      </ul>
    </div>
  </section>
);

export default GymTrainingModule;
