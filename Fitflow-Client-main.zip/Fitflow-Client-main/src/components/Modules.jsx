import React from "react";
import { Link } from "react-router-dom";
import "../style.css"; // if needed for icons or custom styles

const Modules = () => (
  <section className="modules-section" id="modules">
    <div className="modules-content">
      <h2>Explore Our Sports Modules</h2>
      <p>Each module teaches correct form, drills, and sport-specific training.</p>
      <div className="modules-grid">
        <Link to="/modules/cricket" className="module-card">
          <i className="fas fa-baseball-ball icon"></i>
          <h3>Cricket</h3>
          <p>Master batting stance, bowling, and fielding drills.</p>
        </Link>
        <Link to="/modules/football" className="module-card">
          <i className="fas fa-futbol icon"></i>
          <h3>Football</h3>
          <p>Learn passing, dribbling, positioning, and footwork.</p>
        </Link>
        <Link to="/modules/gym" className="module-card">
          <i className="fas fa-dumbbell icon"></i>
          <h3>Gym Training</h3>
          <p>Improve strength, flexibility, and proper posture.</p>
        </Link>
        <Link to="/modules/table-tennis" className="module-card">
          <i className="fas fa-table-tennis icon"></i>
          <h3>Table Tennis</h3>
          <p>Master grip, strokes, and reflex techniques.</p>
        </Link>
      </div>
    </div>
  </section>
);

export default Modules;
