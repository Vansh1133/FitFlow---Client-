// import React, { useState } from "react";

// const SignupModal = ({ onClose, onSignup }) => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const handleSignup = () => {
//     if (!name || !email || !password) {
//       alert("Please fill in all fields");
//       return;
//     }
//     const userData = { name, email, password };
//     localStorage.setItem("sportsUser", JSON.stringify(userData));
//     localStorage.setItem("isLoggedIn", "true");
//     onSignup(name);
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content">
//         <span className="close" onClick={onClose}>&times;</span>
//         <h2>Signup</h2>
//         <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
//         <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
//         <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
//         <button className="btn primary" onClick={handleSignup}>Signup</button>
//       </div>
//     </div>
//   );
// };

// export default SignupModal;

import React, { useState } from "react";

const SignupModal = ({ onClose, onSignup }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSignup = async () => {
    if (!name || !email || !username || !password) {
      setMessage("Please fill in all fields");
      return;
    }
    
    setIsLoading(true);
    setMessage("");
    
    try {
      const response = await fetch('https://fitflow-backend-uxkj.onrender.com/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, username, password })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        // Save user to localStorage
        localStorage.setItem('sportsUser', JSON.stringify(data.user));
        localStorage.setItem('isLoggedIn', 'true');
        onSignup(data.user.name);
        setMessage("Signup successful! You're now logged in.");
        
        // Auto-close modal after successful signup
        setTimeout(onClose, 1500);
      } else {
        setMessage(data.message || "Signup failed");
      }
    } catch (error) {
      console.error("Signup error:", error);
      setMessage("Error connecting to server");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>&times;</span>
        <h2>Signup</h2>
        
        <input 
          type="text" 
          placeholder="Full Name" 
          className="modal-input"
          value={name} 
          onChange={(e) => setName(e.target.value)} 
          required
        />
        
        <input 
          type="email" 
          placeholder="Email" 
          className="modal-input"
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          required
        />
        
        <input 
          type="text" 
          placeholder="Username" 
          className="modal-input"
          value={username} 
          onChange={(e) => setUsername(e.target.value)} 
          required
        />
        
        <input 
          type="password" 
          placeholder="Password" 
          className="modal-input"
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          required
        />
        
        <button 
          className="btn primary" 
          onClick={handleSignup}
          disabled={isLoading}
        >
          {isLoading ? "Creating account..." : "Signup"}
        </button>
        
        {message && (
          <div className={`message ${message.includes("successful") ? "success" : "error"}`}>
            {message}
          </div>
        )}
      </div>
    </div>
  );
};

export default SignupModal;

// import React, { useState } from "react";

// const SignupModal = ({ onClose, onSignup }) => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [message, setMessage] = useState("");
//   const [isLoading, setIsLoading] = useState(false);

//   const handleSignup = async () => {
//     if (!name || !email || !username || !password) {
//       setMessage("Please fill in all fields");
//       return;
//     }
    
//     setIsLoading(true);
//     setMessage("");
    
//     try {
//       const response = await fetch('http://localhost:5000/register', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ name, email, username, password })
//       });
      
//       const data = await response.json();
      
//       if (response.ok) {
//         // Save user to localStorage
//         localStorage.setItem('sportsUser', JSON.stringify(data.user));
//         localStorage.setItem('isLoggedIn', 'true');
//         onSignup(data.user.name);
//         setMessage("Signup successful! You're now logged in.");
        
//         // Auto-close modal after successful signup
//         setTimeout(onClose, 1500);
//       } else {
//         setMessage(data.message || "Signup failed");
//       }
//     } catch (error) {
//       console.error("Signup error:", error);
//       setMessage("Error connecting to server");
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content">
//         <span className="close" onClick={onClose}>&times;</span>
//         <h2>Signup</h2>
        
//         <input 
//           type="text" 
//           placeholder="Full Name" 
//           className="modal-input"
//           value={name} 
//           onChange={(e) => setName(e.target.value)} 
//           required
//         />
        
//         <input 
//           type="email" 
//           placeholder="Email" 
//           className="modal-input"
//           value={email} 
//           onChange={(e) => setEmail(e.target.value)} 
//           required
//         />
        
//         <input 
//           type="text" 
//           placeholder="Username" 
//           className="modal-input"
//           value={username} 
//           onChange={(e) => setUsername(e.target.value)} 
//           required
//         />
        
//         <input 
//           type="password" 
//           placeholder="Password" 
//           className="modal-input"
//           value={password} 
//           onChange={(e) => setPassword(e.target.value)} 
//           required
//         />
        
//         <button 
//           className="btn primary" 
//           onClick={handleSignup}
//           disabled={isLoading}
//         >
//           {isLoading ? "Creating account..." : "Signup"}
//         </button>
        
//         {message && (
//           <div className={`message ${message.includes("successful") ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default SignupModal;
