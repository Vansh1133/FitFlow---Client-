import React from "react";

const CricketModule = () => {
  return (
    <section className="module-container">
      <div className="module-image-container">
        <img
          src="https://t4.ftcdn.net/jpg/13/07/03/13/360_F_1307031398_qq8a3o4Kwp63gUacxKGdBf0K86Nv6UO1.jpg"
          alt="Cricket"
          className="module-image"
        />
      </div>

      <div className="module-content">
        <h2>Cricket Training Module</h2>
        <p>
          Master the core techniques and strategies of cricket through structured training modules.
          Whether you're starting out or refining your play, this guide helps you improve in all key areas.
        </p>
        <ul>
          <li>🏏 <strong>Batting:</strong> Learn grip, stance, backlift, and shot selection</li>
          <li>🎯 <strong>Bowling:</strong> Understand line, length, swing, and spin fundamentals</li>
          <li>🧤 <strong>Fielding:</strong> Improve catching, throwing accuracy, and reflexes</li>
          <li>⚡ <strong>Running Between Wickets:</strong> Build coordination and speed</li>
          <li>🧠 <strong>Game Awareness:</strong> Learn field placements and match tactics</li>
        </ul>
        <p>
          This module builds the foundation for playing smart, technical, and disciplined cricket.
          Suitable for beginners and players aiming to sharpen specific skills.
        </p>
      </div>
    </section>
  );
};

export default CricketModule;
