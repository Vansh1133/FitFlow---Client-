import React, { useState } from "react";

const LoginModal = ({ onClose, onLogin }) => {
  const [formData, setFormData] = useState({
    username: "",
    password: ""
  });
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState(""); // success or error

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("https://fitflow-backend-uxkj.onrender.com/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok && data.success) {
        localStorage.setItem("sportsUser", JSON.stringify(data.user));
        localStorage.setItem("isLoggedIn", "true");
        onLogin(data.user.username);
        setMessage("Login successful!");
        setMessageType("success");
      } else {
        const errorMsg =
          data.message === "Invalid username or password"
            ? "User not found or incorrect password."
            : "Login failed: " + data.message;
        setMessage(errorMsg);
        setMessageType("error");
      }
    } catch (error) {
      setMessage("Error connecting to server");
      setMessageType("error");
    }
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>&times;</span>
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="username"
            placeholder="Username"
            className="modal-input"
            value={formData.username}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            className="modal-input"
            value={formData.password}
            onChange={handleChange}
            required
          />
          <button className="btn primary" type="submit">Login</button>

          {message && (
            <div
              className={`message ${messageType}`}
              style={{
                marginTop: "10px",
                color: messageType === "error" ? "red" : "green",
                fontSize: "0.9rem"
              }}
            >
              {message}
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default LoginModal;


// import React, { useState } from "react";

// const LoginModal = ({ onClose, onLogin }) => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const handleLogin = () => {
//     const storedUser = JSON.parse(localStorage.getItem("sportsUser"));
//     if (!email || !password) {
//       alert("Please fill in all fields");
//       return;
//     }
//     if (storedUser?.email === email.trim() && storedUser?.password === password) {
//       localStorage.setItem("isLoggedIn", "true");
//       onLogin(storedUser.name);
//     } else {
//       alert("Invalid credentials");
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content">
//         <span className="close" onClick={onClose}>&times;</span>
//         <h2>Login</h2>
//         <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
//         <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
//         <button className="btn primary" onClick={handleLogin}>Login</button>
//       </div>
//     </div>
//   );
// };

// export default LoginModal;


// import React, { useState } from "react";

// const LoginModal = ({ onClose, onLogin }) => {
//   const [formData, setFormData] = useState({
//     username: "",
//     password: ""
//   });
//   const [message, setMessage] = useState("");

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
    
//     try {
//       // Send login request to backend
//       const response = await fetch('http://localhost:5000/login', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(formData)
//       });
      
//       const data = await response.json();
      
//       if (data.success) {
//         // Save user to local storage
//         localStorage.setItem('sportsUser', JSON.stringify(data.user));
//         localStorage.setItem('isLoggedIn', 'true');
        
//         // Notify parent component
//         onLogin(data.user.username);
//         setMessage("Login successful!");
//       } else {
//         setMessage("Login failed: " + data.message);
//       }
//     } catch (error) {
//       setMessage("Error connecting to server");
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content">
//         <span className="close" onClick={onClose}>&times;</span>
//         <h2>Login</h2>
//         <form onSubmit={handleSubmit}>
//           <input 
//             type="text" 
//             name="username"
//             placeholder="Username" 
//             className="modal-input"
//             value={formData.username}
//             onChange={handleChange}
//             required
//           />
//           <input 
//             type="password" 
//             name="password"
//             placeholder="Password" 
//             className="modal-input"
//             value={formData.password}
//             onChange={handleChange}
//             required
//           />
//           <button className="btn primary" type="submit">Login</button>
//         </form>
        
//         {message && (
//           <div className={`message ${message.includes("successful") ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default LoginModal;

// import React, { useState } from "react";

// const LoginModal = ({ onClose, onLogin }) => {
//   const [formData, setFormData] = useState({
//     username: "",
//     password: ""
//   });
//   const [message, setMessage] = useState("");

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       const response = await fetch("http://localhost:5000/login", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(formData)
//       });

//       const data = await response.json();

//       if (response.ok && data.success) {
//         localStorage.setItem("sportsUser", JSON.stringify(data.user));
//         localStorage.setItem("isLoggedIn", "true");
//         onLogin(data.user.username);
//         setMessage("Login successful!");
//       } else {
//         // Show specific error messages
//         if (data.message === "Invalid username or password") {
//           setMessage("User not found or wrong password.");
//         } else {
//           setMessage("Login failed: " + data.message);
//         }
//       }
//     } catch (error) {
//       setMessage("Error connecting to server");
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content">
//         <span className="close" onClick={onClose}>&times;</span>
//         <h2>Login</h2>
//         <form onSubmit={handleSubmit}>
//           <input
//             type="text"
//             name="username"
//             placeholder="Username"
//             className="modal-input"
//             value={formData.username}
//             onChange={handleChange}
//             required
//           />
//           <input
//             type="password"
//             name="password"
//             placeholder="Password"
//             className="modal-input"
//             value={formData.password}
//             onChange={handleChange}
//             required
//           />
//           <button className="btn primary" type="submit">Login</button>
//         </form>

//         {message && (
//           <div className={`message ${message.includes("successful") ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default LoginModal;


// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom"; // ✅ Required for redirection

// const LoginModal = ({ onClose, onLogin }) => {
//   const [formData, setFormData] = useState({ username: "", password: "" });
//   const [message, setMessage] = useState("");
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch("http://localhost:5000/login", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(formData)
//       });
//       const data = await response.json();

//       if (data.success) {
//         localStorage.setItem("sportsUser", JSON.stringify(data.user));
//         localStorage.setItem("isLoggedIn", "true");
//         onLogin(data.user.username);
//         setMessage("Login successful!");
//         navigate("/dashboard"); // ✅ Redirect to dashboard
//       } else {
//         setMessage("Login failed: " + data.message);
//       }
//     } catch (error) {
//       setMessage("Error connecting to server");
//     }
//   };

//   return (
//     <div className="modal">
//       <div className="modal-content">
//         <span className="close" onClick={onClose}>
//           &times;
//         </span>
//         <h2>Login</h2>
//         <form onSubmit={handleSubmit}>
//           <input
//             type="text"
//             name="username"
//             placeholder="Username"
//             className="modal-input"
//             value={formData.username}
//             onChange={handleChange}
//             required
//           />
//           <input
//             type="password"
//             name="password"
//             placeholder="Password"
//             className="modal-input"
//             value={formData.password}
//             onChange={handleChange}
//             required
//           />
//           <button className="btn primary" type="submit">
//             Login
//           </button>
//         </form>

//         {message && (
//           <div className={`${message} ${message.includes("successful") ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default LoginModal;