import React from "react";
import { Link } from "react-router-dom";

const GymAvatar = () => {
  return (
    <section className="avatar-detail-page">
      <div className="container">
        <h2>Proper Gym Posture Tutorial</h2>
        <p>Learn the fundamentals of correct gym form to avoid injuries and maximize gains.</p>

        <div className="video-container">
          <iframe
            width="100%"
            height="480"
            src="https://www.youtube.com/embed/XWQvmh_INTQ"
            title="Proper Gym Posture Tutorial"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        <Link to="/" className="back-link">← Back to Home</Link>
      </div>
    </section>
  );
};

export default GymAvatar;
