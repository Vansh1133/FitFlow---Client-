// client/src/components/ChatBox.jsx
import React, { useState } from "react";
import axios from "axios";
import "./chatbox.css";

function ChatBox() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMsg = { sender: "user", text: input };
    setMessages(prev => [...prev, userMsg]);

    try {
      const res = await axios.post(
        "https://fitflow-backend-uxkj.onrender.com/api/ai/chat", // change this to deployed URL later
        { message: input }
      );

      const aiMsg = { sender: "ai", text: res.data.reply };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { sender: "ai", text: "Server error, try again later." }]);
    }

    setInput("");
  };

  return (
    <>
      <div className="chat-icon" onClick={() => setOpen(!open)}>💬</div>

      {open && (
        <div className="chat-box">
          <div className="chat-header">AI Fitness Coach</div>

          <div className="chat-messages">
            {messages.map((msg, i) => (
              <div key={i} className={`msg ${msg.sender}`}>{msg.text}</div>
            ))}
          </div>

          <div className="chat-input">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ask me anything..."
              onKeyPress={e => e.key === "Enter" && sendMessage()}
            />
            <button onClick={sendMessage}>Send</button>
          </div>
        </div>
      )}
    </>
  );
}

export default ChatBox;

// import React, { useState } from "react";
// import axios from "axios";
// import "./chatbox.css";

// function ChatBox() {
//   const [open, setOpen] = useState(false);
//   const [input, setInput] = useState("");
//   const [messages, setMessages] = useState([]);

//   const sendMessage = async () => {
//     if (!input.trim()) return;

//     const userMsg = { sender: "user", text: input };
//     setMessages(prev => [...prev, userMsg]);

//     try {
//       const res = await axios.post("http://localhost:5000/api/ai/chat", {
//         message: input,
//       });

//       const aiMsg = { sender: "ai", text: res.data.reply };
//       setMessages(prev => [...prev, aiMsg]);
//     } catch (error) {
//       setMessages(prev => [
//         ...prev,
//         { sender: "ai", text: "Server error, try again later." }
//       ]);
//     }

//     setInput("");
//   };

//   return (
//     <>
//       <div className="chat-icon" onClick={() => setOpen(!open)}>
//         💬
//       </div>

//       {open && (
//         <div className="chat-box">
//           <div className="chat-header">AI Fitness Coach</div>

//           <div className="chat-messages">
//             {messages.map((msg, i) => (
//               <div key={i} className={`msg ${msg.sender}`}>
//                 {msg.text}
//               </div>
//             ))}
//           </div>

//           <div className="chat-input">
//             <input
//               type="text"
//               value={input}
//               onChange={(e) => setInput(e.target.value)}
//               placeholder="Ask me anything..."
//             />
//             <button onClick={sendMessage}>Send</button>
//           </div>
//         </div>
//       )}
//     </>
//   );
// }

// export default ChatBox;

// import React, { useState } from "react";
// import axios from "axios";
// import "./chatbox.css";

// function ChatBox() {
//   const [open, setOpen] = useState(false);
//   const [input, setInput] = useState("");
//   const [messages, setMessages] = useState([]);

//   const sendMessage = async () => {
//     if (!input.trim()) return;

//     const userMsg = { sender: "user", text: input };
//     setMessages(prev => [...prev, userMsg]);

//     try {
//       const res = await axios.post(
//         "http://localhost:5000/api/ai/chat",
//         { message: input }
//       );

//       const aiMsg = { sender: "ai", text: res.data.reply };
//       setMessages(prev => [...prev, aiMsg]);
//     } catch (err) {
//       setMessages(prev => [
//         ...prev,
//         { sender: "ai", text: "Server error, try again later." }
//       ]);
//     }

//     setInput("");
//   };

//   return (
//     <>
//       <div className="chat-icon" onClick={() => setOpen(!open)}>
//         💬
//       </div>

//       {open && (
//         <div className="chat-box">
//           <div className="chat-header">AI Fitness Coach</div>

//           <div className="chat-messages">
//             {messages.map((msg, i) => (
//               <div key={i} className={`msg ${msg.sender}`}>
//                 {msg.text}
//               </div>
//             ))}
//           </div>

//           <div className="chat-input">
//             <input
//               type="text"
//               value={input}
//               onChange={e => setInput(e.target.value)}
//               placeholder="Ask me anything..."
//             />
//             <button onClick={sendMessage}>Send</button>
//           </div>
//         </div>
//       )}
//     </>
//   );
// }

// export default ChatBox;
