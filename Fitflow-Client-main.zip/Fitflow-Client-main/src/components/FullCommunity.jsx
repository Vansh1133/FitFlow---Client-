import React, { useEffect, useState } from "react";

// Helper to get logged-in user
const getUserName = () => {
  try {
    return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
  } catch {
    return "Anonymous";
  }
};

const FullCommunity = () => {
  const [questions, setQuestions] = useState([]);
  const [questionText, setQuestionText] = useState("");
  const userName = getUserName();

  const fetchQuestions = () => {
    fetch("https://fitflow-backend-uxkj.onrender.com/community")
      .then((res) => res.json())
      .then((data) => setQuestions(data))
      .catch((err) => console.error("Fetch error:", err));
  };

  useEffect(() => {
    fetchQuestions();
  }, []);

  const addQuestion = () => {
    if (!questionText.trim()) return;

    const newQ = {
      text: questionText,
      user: userName,
    };

    fetch("https://fitflow-backend-uxkj.onrender.com/community", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newQ),
    })
      .then((res) => res.json())
      .then((saved) => {
        if (saved.success) {
          setQuestionText("");
          fetchQuestions();
        }
      })
      .catch((err) => console.error("Post error:", err));
  };

  const deleteQuestion = async (id) => {
    if (!window.confirm("Delete this question?")) return;

    const res = await fetch(`https://fitflow-backend-uxkj.onrender.com/community/${id}`, {
      method: "DELETE",
    });

    if (res.ok) {
      fetchQuestions();
    } else {
      alert("Error deleting the question from server.");
    }
  };

  const likeQuestion = async (id) => {
    await fetch(`https://fitflow-backend-uxkj.onrender.com/community/${id}/like`, {
      method: "PATCH",
    });
    fetchQuestions();
  };

  const addComment = async (questionId, commentText) => {
    if (!commentText.trim()) return;

    const res = await fetch(`https://fitflow-backend-uxkj.onrender.com/community/${questionId}/comment`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: commentText, user: userName }),
    });

    if (res.ok) fetchQuestions();
  };

  const deleteComment = async (questionId, commentId) => {
    if (!window.confirm("Delete this comment?")) return;

    const res = await fetch(
      `https://fitflow-backend-uxkj.onrender.com/community/${questionId}/comment/${commentId}`,
      { method: "DELETE" }
    );

    if (res.ok) fetchQuestions();
  };

  return (
    <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
      <h1>Community Q&A</h1>

      <textarea
        value={questionText}
        onChange={(e) => setQuestionText(e.target.value)}
        placeholder="Ask your question..."
        style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
        rows={3}
      />
      <button
        onClick={addQuestion}
        style={{
          marginTop: "10px",
          padding: "10px 20px",
          backgroundColor: "#5bc0be",
          color: "#fff",
          border: "none",
          borderRadius: "6px",
          cursor: "pointer",
        }}
      >
        Post Question
      </button>

      {questions.length === 0 ? (
        <p style={{ marginTop: "2rem", color: "#aaa" }}>
          No questions yet. Be the first to ask!
        </p>
      ) : (
        questions.map((q) => (
          <div
            key={q._id}
            style={{
              background: "#1c2541",
              padding: "1rem",
              borderRadius: "10px",
              marginTop: "2rem",
              color: "white",
            }}
          >
            <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
            <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
              Posted by {q.user}
            </p>

            <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
              <button
                onClick={() => likeQuestion(q._id)}
                style={{
                  background: "#3a506b",
                  color: "white",
                  border: "none",
                  padding: "6px 10px",
                  borderRadius: "6px",
                  cursor: "pointer",
                }}
              >
                👍 {q.likes || 0}
              </button>
              <button
                onClick={() => deleteQuestion(q._id)}
                style={{
                  background: "#ff4d4d",
                  color: "white",
                  border: "none",
                  padding: "6px 10px",
                  borderRadius: "6px",
                  cursor: "pointer",
                }}
              >
                🗑️ Delete
              </button>
            </div>

            <CommentSection
              comments={q.comments || []}
              onAdd={(text) => addComment(q._id, text)}
              onDelete={(cid) => deleteComment(q._id, cid)}
            />
          </div>
        ))
      )}
    </div>
  );
};

const CommentSection = ({ comments = [], onAdd, onDelete }) => {
  const [text, setText] = useState("");

  const handleSubmit = () => {
    if (!text.trim()) return;
    onAdd(text);
    setText("");
  };

  return (
    <div style={{ marginTop: "1rem" }}>
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Add a comment"
        style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
      />
      <button
        onClick={handleSubmit}
        style={{
          marginLeft: "10px",
          padding: "8px 16px",
          backgroundColor: "#5bc0be",
          color: "#fff",
          border: "none",
          borderRadius: "6px",
          cursor: "pointer",
        }}
      >
        Comment
      </button>

      <div style={{ marginTop: "1rem" }}>
        {comments.map((c) => (
          <div
            key={c._id}
            style={{
              marginBottom: "0.5rem",
              paddingBottom: "0.5rem",
              borderBottom: "1px solid #3a506b",
            }}
          >
            <p>
              <strong>{c.user}</strong>: {c.text}
            </p>
            <button
              onClick={() => onDelete(c._id)}
              style={{
                background: "transparent",
                border: "none",
                color: "#ccc",
                fontSize: "0.85rem",
                cursor: "pointer",
              }}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FullCommunity;

// import React, { useEffect, useState } from "react";

// // Helper to get logged-in user
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");

//   const userName = getUserName();

//   useEffect(() => {
//     fetch("http://localhost:5000/community")
//       .then((res) => res.json())
//       .then((data) => setQuestions(data))
//       .catch((err) => console.error("Fetch error:", err));
//   }, []);

//   const addQuestion = () => {
//     if (!questionText.trim()) return;
//     const newQ = {
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };

//     fetch("http://localhost:5000/community", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(newQ),
//     })
//       .then((res) => res.json())
//       .then((saved) => {
//         if (saved.success && saved.data) {
//           setQuestions([saved.data, ...questions]);
//           setQuestionText("");
//         }
//       })
//       .catch((err) => console.error("Post error:", err));
//   };

//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;

//     const res = await fetch(`http://localhost:5000/community/${id}`, {
//       method: "DELETE",
//     });

//     if (res.ok) {
//       setQuestions((prev) => prev.filter((q) => q._id !== id));
//     } else {
//       alert("Error deleting the question from server.");
//     }
//   };

//   const likeQuestion = (id) => {
//     setQuestions(
//       questions.map((q) =>
//         q._id === id ? { ...q, likes: q.likes + 1 } : q
//       )
//     );
//   };

//   const addComment = (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     setQuestions((prev) =>
//       prev.map((q) =>
//         q._id === questionId
//           ? {
//               ...q,
//               comments: [
//                 ...q.comments,
//                 { id: crypto.randomUUID(), text: commentText, user: userName },
//               ],
//             }
//           : q
//       )
//     );
//   };

//   const deleteComment = (questionId, commentId) => {
//     if (window.confirm("Delete this comment?")) {
//       setQuestions((prev) =>
//         prev.map((q) =>
//           q._id === questionId
//             ? {
//                 ...q,
//                 comments: q.comments.filter((c) => c.id !== commentId),
//               }
//             : q
//         )
//       );
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q._id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q._id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q._id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments || []}
//               onAdd={(text) => addComment(q._id, text)}
//               onDelete={(cid) => deleteComment(q._id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// const CommentSection = ({ comments = [], onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;

// import React, { useEffect, useState } from "react";

// // Helper to get logged-in user
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");

//   const userName = getUserName();

//   useEffect(() => {
//     fetch("http://localhost:5000/community")
//       .then((res) => res.json())
//       .then((data) => setQuestions(data))
//       .catch((err) => console.error("Fetch error:", err));
//   }, []);

//   const addQuestion = () => {
//     if (!questionText.trim()) return;
//     const newQ = {
//       id: crypto.randomUUID(),
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };

//     fetch("http://localhost:5000/community", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(newQ),
//     })
//       .then((res) => res.json())
//       .then((saved) => {
//         setQuestions([saved, ...questions]);
//         setQuestionText("");
//       })
//       .catch((err) => console.error("Post error:", err));
//   };

//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;

//     const res = await fetch(`http://localhost:5000/community/${id}`, {
//       method: "DELETE",
//     });

//     if (res.ok) {
//       setQuestions((prev) => prev.filter((q) => q.id !== id));
//     } else {
//       alert("Error deleting the question from server.");
//     }
//   };

//   const likeQuestion = (id) => {
//     setQuestions(
//       questions.map((q) =>
//         q.id === id ? { ...q, likes: q.likes + 1 } : q
//       )
//     );
//   };

//   const addComment = (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     setQuestions((prev) =>
//       prev.map((q) =>
//         q.id === questionId
//           ? {
//               ...q,
//               comments: [
//                 ...q.comments,
//                 { id: crypto.randomUUID(), text: commentText, user: userName },
//               ],
//             }
//           : q
//       )
//     );
//   };

//   const deleteComment = (questionId, commentId) => {
//     if (window.confirm("Delete this comment?")) {
//       setQuestions((prev) =>
//         prev.map((q) =>
//           q.id === questionId
//             ? {
//                 ...q,
//                 comments: q.comments.filter((c) => c.id !== commentId),
//               }
//             : q
//         )
//       );
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments || []}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// const CommentSection = ({ comments = [], onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;


// import React, { useEffect, useState } from "react";

// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // Fetch on mount
//   useEffect(() => {
//     fetch("http://localhost:5000/community")
//       .then((res) => res.json())
//       .then((data) => {
//         setQuestions(data.reverse());
//       })
//       .catch((err) => {
//         console.error("Error fetching community questions:", err);
//       });
//   }, []);

//   // Post new question
//   const addQuestion = async () => {
//     if (!questionText.trim()) return;

//     const newQ = {
//       id: crypto.randomUUID(),
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };

//     try {
//       const res = await fetch("http://localhost:5000/community", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(newQ),
//       });

//       if (res.ok) {
//         setQuestions((prev) => [newQ, ...prev]);
//         setQuestionText("");
//       }
//     } catch (err) {
//       console.error("Error adding question:", err);
//     }
//   };

//   // ✅ Delete question from DB and UI
//   const deleteQuestion = async (id) => {
//     const confirmed = window.confirm("Delete this question?");
//     if (!confirmed) return;

//     try {
//       const res = await fetch(`http://localhost:5000/community/${id}`, {
//         method: "DELETE",
//       });

//       if (res.ok) {
//         setQuestions((prev) => prev.filter((q) => q.id !== id));
//       } else {
//         console.error("Backend delete failed");
//       }
//     } catch (err) {
//       console.error("Error deleting question:", err);
//     }
//   };

//   const likeQuestion = (id) => {
//     setQuestions((prev) =>
//       prev.map((q) => (q.id === id ? { ...q, likes: q.likes + 1 } : q))
//     );
//     fetch(`http://localhost:5000/community/like/${id}`, { method: "POST" });
//   };

//   const addComment = (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     const newComment = {
//       id: crypto.randomUUID(),
//       text: commentText,
//       user: userName,
//     };

//     setQuestions((prev) =>
//       prev.map((q) =>
//         q.id === questionId
//           ? { ...q, comments: [...(q.comments || []), newComment] }
//           : q
//       )
//     );

//     fetch(`http://localhost:5000/community/comment/${questionId}`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(newComment),
//     });
//   };

//   const deleteComment = async (questionId, commentId) => {
//     const confirmed = window.confirm("Delete this comment?");
//     if (!confirmed) return;

//     try {
//       const res = await fetch(
//         `http://localhost:5000/community/comment/${questionId}/${commentId}`,
//         { method: "DELETE" }
//       );

//       if (res.ok) {
//         setQuestions((prev) =>
//           prev.map((q) =>
//             q.id === questionId
//               ? {
//                   ...q,
//                   comments: (q.comments || []).filter((c) => c.id !== commentId),
//                 }
//               : q
//           )
//         );
//       }
//     } catch (err) {
//       console.error("Error deleting comment:", err);
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments || []}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// // ✅ Comment Section
// const CommentSection = ({ comments = [], onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;


// import React, { useEffect, useState } from "react";

// // Helper to safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");

//   const userName = getUserName();

//   useEffect(() => {
//     // Fetch all questions from DB on load
//     fetch("http://localhost:5000/community")
//       .then((res) => res.json())
//       .then((data) => {
//         setQuestions(data.reverse()); // Optional: show latest first
//       })
//       .catch((err) => {
//         console.error("Error fetching community questions:", err);
//       });
//   }, []);

//   const addQuestion = async () => {
//     if (!questionText.trim()) return;
//     const newQ = {
//       id: crypto.randomUUID(),
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };

//     try {
//       const res = await fetch("http://localhost:5000/community", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(newQ),
//       });

//       if (res.ok) {
//         setQuestions((prev) => [newQ, ...prev]);
//         setQuestionText("");
//       }
//     } catch (err) {
//       console.error("Error adding question:", err);
//     }
//   };

//   const deleteQuestion = (id) => {
//     if (window.confirm("Delete this question?")) {
//       setQuestions((prev) => prev.filter((q) => q.id !== id));
//       fetch(`http://localhost:5000/community/${id}`, { method: "DELETE" });
//     }
//   };

//   const likeQuestion = (id) => {
//     setQuestions((prev) =>
//       prev.map((q) =>
//         q.id === id ? { ...q, likes: q.likes + 1 } : q
//       )
//     );

//     fetch(`http://localhost:5000/community/like/${id}`, {
//       method: "POST",
//     });
//   };

//   const addComment = (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     const newComment = {
//       id: crypto.randomUUID(),
//       text: commentText,
//       user: userName,
//     };

//     setQuestions((prev) =>
//       prev.map((q) =>
//         q.id === questionId
//           ? { ...q, comments: [...(q.comments || []), newComment] }
//           : q
//       )
//     );

//     fetch(`http://localhost:5000/community/comment/${questionId}`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(newComment),
//     });
//   };

//   const deleteComment = (questionId, commentId) => {
//     if (window.confirm("Delete this comment?")) {
//       setQuestions((prev) =>
//         prev.map((q) =>
//           q.id === questionId
//             ? {
//                 ...q,
//                 comments: (q.comments || []).filter((c) => c.id !== commentId),
//               }
//             : q
//         )
//       );

//       fetch(`http://localhost:5000/community/comment/${questionId}/${commentId}`, {
//         method: "DELETE",
//       });
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments || []}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// // 👇 Comment Section - with default empty array for safety
// const CommentSection = ({ comments = [], onAdd, onDelete }) => {
//   const [text, setText] = useState("");

//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;

// import React, { useEffect, useState } from "react";

// // Safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // Fetch questions from DB on mount
//   useEffect(() => {
//     fetch("http://localhost:5000/community")
//       .then((res) => res.json())
//       .then((data) => setQuestions(data))
//       .catch((err) => console.error("Fetch error:", err));
//   }, []);

//   // Add new question
//   const addQuestion = async () => {
//     if (!questionText.trim()) return;
//     const newQ = {
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };
//     const res = await fetch("http://localhost:5000/community", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(newQ),
//     });
//     const saved = await res.json();
//     setQuestions([saved, ...questions]);
//     setQuestionText("");
//   };

//   // Delete a question
//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;
//     await fetch(`http://localhost:5000/community/${id}`, {
//       method: "DELETE",
//     });
//     setQuestions(questions.filter((q) => q._id !== id));
//   };

//   // Like a question
//   const likeQuestion = async (id) => {
//     const res = await fetch(`http://localhost:5000/community/${id}/like`, {
//       method: "PATCH",
//     });
//     const updated = await res.json();
//     setQuestions(questions.map((q) => (q._id === id ? updated : q)));
//   };

//   // Add comment
//   const addComment = async (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     const newComment = { text: commentText, user: userName };
//     const res = await fetch(`http://localhost:5000/community/${questionId}/comment`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(newComment),
//     });
//     const updated = await res.json();
//     setQuestions(questions.map((q) => (q._id === questionId ? updated : q)));
//   };

//   // Delete comment
//   const deleteComment = async (questionId, commentId) => {
//     if (!window.confirm("Delete this comment?")) return;
//     const res = await fetch(`http://localhost:5000/community/${questionId}/comment/${commentId}`, {
//       method: "DELETE",
//     });
//     const updated = await res.json();
//     setQuestions(questions.map((q) => (q._id === questionId ? updated : q)));
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q._id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q._id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q._id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments}
//               onAdd={(text) => addComment(q._id, text)}
//               onDelete={(cid) => deleteComment(q._id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// const CommentSection = ({ comments, onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;


// import React, { useEffect, useState } from "react";

// // Helper to safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // ✅ Fetch questions from MongoDB on page load
//   useEffect(() => {
//     const fetchQuestions = async () => {
//       try {
//         const res = await fetch("http://localhost:5000/community");
//         const data = await res.json();
//         setQuestions(data);
//       } catch (error) {
//         console.error("Error fetching questions:", error);
//       }
//     };

//     fetchQuestions();
//   }, []);

//   const addQuestion = async () => {
//     if (!questionText.trim()) return;

//     const newQ = {
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };

//     try {
//       const res = await fetch("http://localhost:5000/community", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(newQ),
//       });

//       const result = await res.json();

//       if (result.success) {
//         // Use returned MongoDB _id
//         setQuestions([{ ...newQ, _id: result.id }, ...questions]);
//         setQuestionText("");
//       }
//     } catch (err) {
//       console.error("Failed to post question:", err);
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q._id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <CommentSection
//               comments={q.comments || []}
//               onAdd={() => {}}
//               onDelete={() => {}}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// const CommentSection = ({ comments }) => {
//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c, index) => (
//           <div
//             key={index}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;


// import React, { useEffect, useState } from "react";

// // Helper to safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");

//   const userName = getUserName();

//   useEffect(() => {
//     const stored = localStorage.getItem("communityQuestions");
//     if (stored) {
//       setQuestions(JSON.parse(stored));
//     }
//   }, []);

//   useEffect(() => {
//     localStorage.setItem("communityQuestions", JSON.stringify(questions));
//   }, [questions]);

//   const addQuestion = () => {
//     if (!questionText.trim()) return;
//     const newQ = {
//       id: crypto.randomUUID(),
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };
//     setQuestions([newQ, ...questions]);
//     setQuestionText("");
//     fetch("http://localhost:5000/community", {
//     method: "POST",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify(newQ),
// });
//   };

//   const deleteQuestion = (id) => {
//     if (window.confirm("Delete this question?")) {
//       setQuestions(questions.filter((q) => q.id !== id));
//     }
//   };

//   const likeQuestion = (id) => {
//     setQuestions(
//       questions.map((q) =>
//         q.id === id ? { ...q, likes: q.likes + 1 } : q
//       )
//     );
//   };

//   const addComment = (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     setQuestions((prev) =>
//       prev.map((q) =>
//         q.id === questionId
//           ? {
//               ...q,
//               comments: [
//                 ...q.comments,
//                 { id: crypto.randomUUID(), text: commentText, user: userName },
//               ],
//             }
//           : q
//       )
//     );
//   };

//   const deleteComment = (questionId, commentId) => {
//     if (window.confirm("Delete this comment?")) {
//       setQuestions((prev) =>
//         prev.map((q) =>
//           q.id === questionId
//             ? {
//                 ...q,
//                 comments: q.comments.filter((c) => c.id !== commentId),
//               }
//             : q
//         )
//       );
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// const CommentSection = ({ comments, onAdd, onDelete }) => {
//   const [text, setText] = useState("");

//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;




// import React, { useEffect, useState } from "react";

// // Helper to safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const CommentSection = ({ comments, onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // Fetch questions from backend
//   const fetchQuestions = async () => {
//     try {
//       const response = await fetch('/api/questions');
//       const data = await response.json();
//       setQuestions(data);
//     } catch (error) {
//       console.error("Failed to load questions:", error);
//     }
//   };

//   useEffect(() => {
//     fetchQuestions();
//   }, []);

//   // Post new question to backend
//   const addQuestion = async () => {
//     if (!questionText.trim()) return;
    
//     try {
//       const response = await fetch('/api/questions', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: questionText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         setQuestionText("");
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post question:", error);
//     }
//   };

//   // Update like count in backend
//   const likeQuestion = async (id) => {
//     try {
//       await fetch(`/api/questions/${id}/like`, {
//         method: 'PUT'
//       });
//       fetchQuestions();
//     } catch (error) {
//       console.error("Failed to like question:", error);
//     }
//   };

//   // Delete question from backend
//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;
    
//     try {
//       const response = await fetch(`/api/questions/${id}`, {
//         method: 'DELETE'
//       });
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete question:", error);
//     }
//   };

//   // Add comment to backend
//   const addComment = async (questionId, commentText) => {
//     if (!commentText.trim()) return;
    
//     try {
//       const response = await fetch(`/api/questions/${questionId}/comments`, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: commentText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post comment:", error);
//     }
//   };

//   // Delete comment from backend
//   const deleteComment = async (questionId, commentId) => {
//     if (!window.confirm("Delete this comment?")) return;
    
//     try {
//       const response = await fetch(
//         `/api/questions/${questionId}/comments/${commentId}`, 
//         { method: 'DELETE' }
//       );
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete comment:", error);
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// export default FullCommunity;

// import React, { useEffect, useState } from "react";

// // Helper to safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const CommentSection = ({ comments, onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // Fetch questions from backend
//   const fetchQuestions = async () => {
//     try {
//       const response = await fetch('/api/questions');
//       const data = await response.json();
//       setQuestions(data);
//     } catch (error) {
//       console.error("Failed to load questions:", error);
//     }
//   };

//   useEffect(() => {
//     fetchQuestions();
//   }, []);

//   // Post new question to backend
//   const addQuestion = async () => {
//     if (!questionText.trim()) return;
    
//     try {
//       const response = await fetch('/api/questions', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: questionText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         setQuestionText("");
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post question:", error);
//     }
//   };

//   // Update like count in backend
//   const likeQuestion = async (id) => {
//     try {
//       await fetch(`/api/questions/${id}/like`, {
//         method: 'PUT'
//       });
//       fetchQuestions();
//     } catch (error) {
//       console.error("Failed to like question:", error);
//     }
//   };

//   // Delete question from backend
//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;
    
//     try {
//       const response = await fetch(`/api/questions/${id}`, {
//         method: 'DELETE'
//       });
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete question:", error);
//     }
//   };

//   // Add comment to backend
//   const addComment = async (questionId, commentText) => {
//     if (!commentText.trim()) return;
    
//     try {
//       const response = await fetch(`/api/questions/${questionId}/comments`, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: commentText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post comment:", error);
//     }
//   };

//   // Delete comment from backend
//   const deleteComment = async (questionId, commentId) => {
//     if (!window.confirm("Delete this comment?")) return;
    
//     try {
//       const response = await fetch(
//         `/api/questions/${questionId}/comments/${commentId}`, 
//         { method: 'DELETE' }
//       );
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete comment:", error);
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// export default FullCommunity;



// import React, { useEffect, useState } from "react";

// // Helper to safely get logged-in user name
// const getUserName = () => {
//   try {
//     return JSON.parse(localStorage.getItem("sportsUser"))?.name || "Anonymous";
//   } catch {
//     return "Anonymous";
//   }
// };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");

//   const userName = getUserName();

//   useEffect(() => {
//     const stored = localStorage.getItem("communityQuestions");
//     if (stored) {
//       setQuestions(JSON.parse(stored));
//     }
//   }, []);

//   useEffect(() => {
//     localStorage.setItem("communityQuestions", JSON.stringify(questions));
//   }, [questions]);

//   const addQuestion = () => {
//     if (!questionText.trim()) return;
//     const newQ = {
//       id: crypto.randomUUID(),
//       text: questionText,
//       user: userName,
//       comments: [],
//       likes: 0,
//     };
//     setQuestions([newQ, ...questions]);
//     setQuestionText("");
//   };

//   const deleteQuestion = (id) => {
//     if (window.confirm("Delete this question?")) {
//       setQuestions(questions.filter((q) => q.id !== id));
//     }
//   };

//   const likeQuestion = (id) => {
//     setQuestions(
//       questions.map((q) =>
//         q.id === id ? { ...q, likes: q.likes + 1 } : q
//       )
//     );
//   };

//   const addComment = (questionId, commentText) => {
//     if (!commentText.trim()) return;
//     setQuestions((prev) =>
//       prev.map((q) =>
//         q.id === questionId
//           ? {
//               ...q,
//               comments: [
//                 ...q.comments,
//                 { id: crypto.randomUUID(), text: commentText, user: userName },
//               ],
//             }
//           : q
//       )
//     );
//   };

//   const deleteComment = (questionId, commentId) => {
//     if (window.confirm("Delete this comment?")) {
//       setQuestions((prev) =>
//         prev.map((q) =>
//           q.id === questionId
//             ? {
//                 ...q,
//                 comments: q.comments.filter((c) => c.id !== commentId),
//               }
//             : q
//         )
//       );
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
//       <h1>Community Q&A</h1>

//       <textarea
//         value={questionText}
//         onChange={(e) => setQuestionText(e.target.value)}
//         placeholder="Ask your question..."
//         style={{ width: "100%", padding: "10px", borderRadius: "8px" }}
//         rows={3}
//       />
//       <button
//         onClick={addQuestion}
//         style={{
//           marginTop: "10px",
//           padding: "10px 20px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Post Question
//       </button>

//       {questions.length === 0 ? (
//         <p style={{ marginTop: "2rem", color: "#aaa" }}>
//           No questions yet. Be the first to ask!
//         </p>
//       ) : (
//         questions.map((q) => (
//           <div
//             key={q.id}
//             style={{
//               background: "#1c2541",
//               padding: "1rem",
//               borderRadius: "10px",
//               marginTop: "2rem",
//               color: "white",
//             }}
//           >
//             <p style={{ fontSize: "1.1rem" }}>{q.text}</p>
//             <p style={{ fontSize: "0.9rem", color: "#aaa" }}>
//               Posted by {q.user}
//             </p>

//             <div style={{ marginTop: "0.5rem", display: "flex", gap: "10px" }}>
//               <button
//                 onClick={() => likeQuestion(q.id)}
//                 style={{
//                   background: "#3a506b",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 👍 {q.likes}
//               </button>
//               <button
//                 onClick={() => deleteQuestion(q.id)}
//                 style={{
//                   background: "#ff4d4d",
//                   color: "white",
//                   border: "none",
//                   padding: "6px 10px",
//                   borderRadius: "6px",
//                   cursor: "pointer",
//                 }}
//               >
//                 🗑️ Delete
//               </button>
//             </div>

//             <CommentSection
//               comments={q.comments}
//               onAdd={(text) => addComment(q.id, text)}
//               onDelete={(cid) => deleteComment(q.id, cid)}
//             />
//           </div>
//         ))
//       )}
//     </div>
//   );
// };

// const CommentSection = ({ comments, onAdd, onDelete }) => {
//   const [text, setText] = useState("");

//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;

// import React, { useEffect, useState } from "react";

// const getUserName = () => { /* unchanged */ };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // Fetch questions from backend
//   const fetchQuestions = async () => {
//     try {
//       const response = await fetch('/api/questions');
//       const data = await response.json();
//       setQuestions(data);
//     } catch (error) {
//       console.error("Failed to load questions:", error);
//     }
//   };

//   useEffect(() => {
//     fetchQuestions();
//   }, []);

//   // Post new question to backend
//   const addQuestion = async () => {
//     if (!questionText.trim()) return;
    
//     try {
//       const response = await fetch('/api/questions', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: questionText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         setQuestionText("");
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post question:", error);
//     }
//   };

//   // Update like count in backend
//   const likeQuestion = async (id) => {
//     try {
//       await fetch(`/api/questions/${id}/like`, {
//         method: 'PUT'
//       });
//       fetchQuestions();
//     } catch (error) {
//       console.error("Failed to like question:", error);
//     }
//   };

//   // Delete question from backend
//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;
    
//     try {
//       const response = await fetch(`/api/questions/${id}`, {
//         method: 'DELETE'
//       });
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete question:", error);
//     }
//   };

//   // Add comment to backend
//   const addComment = async (questionId, commentText) => {
//     if (!commentText.trim()) return;
    
//     try {
//       const response = await fetch(`/api/questions/${questionId}/comments`, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: commentText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post comment:", error);
//     }
//   };

//   // Delete comment from backend
//   const deleteComment = async (questionId, commentId) => {
//     if (!window.confirm("Delete this comment?")) return;
    
//     try {
//       const response = await fetch(
//         `/api/questions/${questionId}/comments/${commentId}`, 
//         { method: 'DELETE' }
//       );
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete comment:", error);
//     }
//   };

//   return (
//     /* Unchanged JSX structure */
//   );
// };

// import React, { useEffect, useState } from "react";

// const getUserName = () => { /* unchanged */ };

// const FullCommunity = () => {
//   const [questions, setQuestions] = useState([]);
//   const [questionText, setQuestionText] = useState("");
//   const userName = getUserName();

//   // Fetch questions from backend
//   const fetchQuestions = async () => {
//     try {
//       const response = await fetch('/api/questions');
//       const data = await response.json();
//       setQuestions(data);
//     } catch (error) {
//       console.error("Failed to load questions:", error);
//     }
//   };

//   useEffect(() => {
//     fetchQuestions();
//   }, []);

//   // Post new question to backend
//   const addQuestion = async () => {
//     if (!questionText.trim()) return;
    
//     try {
//       const response = await fetch('/api/questions', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: questionText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         setQuestionText("");
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post question:", error);
//     }
//   };

//   // Update like count in backend
//   const likeQuestion = async (id) => {
//     try {
//       await fetch(`/api/questions/${id}/like`, {
//         method: 'PUT'
//       });
//       fetchQuestions();
//     } catch (error) {
//       console.error("Failed to like question:", error);
//     }
//   };

//   // Delete question from backend
//   const deleteQuestion = async (id) => {
//     if (!window.confirm("Delete this question?")) return;
    
//     try {
//       const response = await fetch(`/api/questions/${id}`, {
//         method: 'DELETE'
//       });
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete question:", error);
//     }
//   };

//   // Add comment to backend
//   const addComment = async (questionId, commentText) => {
//     if (!commentText.trim()) return;
    
//     try {
//       const response = await fetch(`/api/questions/${questionId}/comments`, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           text: commentText, 
//           user: userName 
//         })
//       });
      
//       if (response.ok) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to post comment:", error);
//     }
//   };

//   // Delete comment from backend
//   const deleteComment = async (questionId, commentId) => {
//     if (!window.confirm("Delete this comment?")) return;
    
//     try {
//       const response = await fetch(
//         `/api/questions/${questionId}/comments/${commentId}`, 
//         { method: 'DELETE' }
//       );
      
//       if (response.status === 204) {
//         fetchQuestions();
//       }
//     } catch (error) {
//       console.error("Failed to delete comment:", error);
//     }
//   };

//   return (
//         <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;



// ... FullCommunity component code ...

// MOVE THIS COMPONENT OUTSIDE FullCommunity
// const CommentSection = ({ comments, onAdd, onDelete }) => {
//   const [text, setText] = useState("");
//   const userName = getUserName();

//   const handleSubmit = () => {
//     if (!text.trim()) return;
//     onAdd(text);
//     setText("");
//   };

//   return (
//     <div style={{ marginTop: "1rem" }}>
//       <input
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Add a comment"
//         style={{ padding: "8px", width: "65%", borderRadius: "6px" }}
//       />
//       <button
//         onClick={handleSubmit}
//         style={{
//           marginLeft: "10px",
//           padding: "8px 16px",
//           backgroundColor: "#5bc0be",
//           color: "#fff",
//           border: "none",
//           borderRadius: "6px",
//           cursor: "pointer",
//         }}
//       >
//         Comment
//       </button>

//       <div style={{ marginTop: "1rem" }}>
//         {comments.map((c) => (
//           <div
//             key={c.id}
//             style={{
//               marginBottom: "0.5rem",
//               paddingBottom: "0.5rem",
//               borderBottom: "1px solid #3a506b",
//             }}
//           >
//             <p>
//               <strong>{c.user}</strong>: {c.text}
//             </p>
//             <button
//               onClick={() => onDelete(c.id)}
//               style={{
//                 background: "transparent",
//                 border: "none",
//                 color: "#ccc",
//                 fontSize: "0.85rem",
//                 cursor: "pointer",
//               }}
//             >
//               Delete
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FullCommunity;
