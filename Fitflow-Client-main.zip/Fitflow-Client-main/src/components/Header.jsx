import React from "react";
import { Link } from "react-router-dom";

const Header = ({ isLoggedIn, userName, onLogout, onLogin, onSignup }) => {
  return (
    <header className="navbar">
      <div className="logo">
        <img src="https://i.pinimg.com/736x/ff/ea/ef/ffeaefac4eb3c25bd0aeaefa159cf60e.jpg" alt="Logo" />
        <span>Fit Flow</span>
      </div>
      <div className="hamburger" onClick={() => document.getElementById("nav").classList.toggle("active")}>
        <i className="fas fa-bars"></i>
      </div>
      <nav className="nav-links" id="nav">
        {/* <a href="#home">Home</a> */}
        <Link to="/">Home</Link>
        <a href="#modules">Modules</a>
        <a href="#progress">Progress</a>

        {!isLoggedIn ? (
          <>
            <button className="nav-btn" onClick={onLogin}>Login</button>
            <button className="nav-btn" onClick={onSignup}>Signup</button>
          </>
        ) : (
          <span className="welcome-msg">
            👋 Welcome, {userName}! <span className="logout-link" onClick={onLogout}>Logout</span>
          </span>
        )}
      </nav>
    </header>
  );
};

export default Header;
