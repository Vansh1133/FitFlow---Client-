import React from "react";

const FootballModule = () => (
  <section className="module-container">
    <div className="module-image-container">
      <img
        src="https://wallpapers.com/images/hd/greatest-footballer-lock-screen-ddxi62b9c8cfkkg9.jpg"
        alt="Football"
        className="module-image"
      />
    </div>

    <div className="module-content">
      <h2>Football Training Module</h2>
      <p>
        Improve your football performance through structured drills and skill-focused sessions.
        This module helps players of all levels build a solid foundation in ball control,
        strategy, and movement—ensuring you're prepared for real match scenarios.
      </p>
      <ul>
        <li>⚽ <strong>Ball Control:</strong> Develop close control and smooth dribbling techniques</li>
        <li>🎯 <strong>Passing & Shooting:</strong> Execute sharp passes and accurate goal shots</li>
        <li>📍 <strong>Positioning:</strong> Learn tactical awareness and role-based positioning</li>
        <li>🧠 <strong>Decision Making:</strong> Improve game intelligence and quick responses</li>
        <li>🏃 <strong>Speed & Agility:</strong> Train footwork, sprint starts, and direction changes</li>
        <li>🛡️ <strong>Defensive Skills:</strong> Practice marking, interceptions, and tackling</li>
        <li>🚀 <strong>Set Pieces:</strong> Understand corner kicks, free kicks, and penalties</li>
      </ul>
      <p>
        Whether you're a beginner or experienced player, this module equips you with the tools
        to enhance individual performance and contribute meaningfully to your team.
      </p>
    </div>
  </section>
);

export default FootballModule;
