import React from "react";

const TableTennis = () => (
  <section className="module-container">
    <div className="module-image-container">
      <img
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Table_Tennis_Table_Blue.svg/500px-Table_Tennis_Table_Blue.svg.png"
        alt="Table Tennis Table"
        className="module-image"
      />
    </div>

    <div className="module-content">
      <h2>Table Tennis Module</h2>
      <p>
        Table tennis, also known as Ping-Pong, is a fast-paced and exciting sport.
        Whether you're aiming to improve your skills or understand the game's nuances, this module covers all.
      </p>

      <h3>1. Mastering the Fundamentals</h3>
      <ul>
        <li><strong>Equipment:</strong> Racket, ball, table, and net.</li>
        <li><strong>Grip & Stance:</strong> Shakehand and penhold styles.</li>
        <li><strong>Strokes:</strong> Drive, push, flick, and loop.</li>
        <li><strong>Strategies:</strong> Handle spin, footwork, and opponent reading.</li>
      </ul>

      <h3>2. Quick Benefits</h3>
      <ul>
        <li>⚡ Improves reflexes and hand-eye coordination</li>
        <li>🧠 Enhances focus and cognitive ability</li>
        <li>💪 Builds agility and fitness</li>
        <li>🤝 Fosters social interaction and community</li>
      </ul>
    </div>
  </section>
);

export default TableTennis;
