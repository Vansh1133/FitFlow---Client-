// import React from "react";

// const Hero = () => (
//   <section className="hero" id="home">
//     <div className="hero-content">
//       <h1><span>Train Smart</span> with AI-Enhanced Sports Guidance</h1>
//       <p>Improve your technique, learn correct posture, and manage your training across 7+ sports with expert-backed tutorials.</p>
//       <div className="hero-buttons">
//         <button className="btn primary">Start Learning Free</button>
//         <button className="btn secondary">Watch Demo</button>
//       </div>
//       <div className="stats">
//         <div><strong>10+</strong><br />Sports Covered</div>
//         <div><strong>500+</strong><br />Tutorials</div>
//         <div><strong>24/7</strong><br />Support</div>
//         <div><strong>95%</strong><br />User Success</div>
//       </div>
//     </div>
//     <div className="hero-image">
//       <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRw3UbUHhu2mrdtmLMFxULuqO167GPh2koWqw&s" alt="Athlete Training" />
//     </div>
//   </section>
// );

// export default Hero;



import React, { useState } from "react";

const Hero = () => {
  const [showVideo, setShowVideo] = useState(false);

  return (
    <section
      style={{
        background: "#0b1120",
        color: "white",
        padding: "3rem 2rem",
        textAlign: "center",
      }}
    >
      <h1 style={{ fontSize: "2.5rem", marginBottom: "1rem" }}>
        Train Smart with AI-Enhanced Sports Guidance
      </h1>
      <p style={{ fontSize: "1.2rem", marginBottom: "2rem" }}>
        Improve your technique, learn posture, and access expert tutorials.
      </p>

      <div style={{ marginBottom: "2rem" }}>
        <button
          style={{
            background: "#1d4ed8",
            color: "white",
            border: "none",
            padding: "0.8rem 1.5rem",
            borderRadius: "8px",
            marginRight: "1rem",
            cursor: "pointer",
          }}
        >
          Start Learning Free
        </button>
        <button
          onClick={() => setShowVideo(true)}
          style={{
            background: "white",
            color: "#1d4ed8",
            border: "none",
            padding: "0.8rem 1.5rem",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          Watch Demo
        </button>
      </div>

      {/* Stats Section */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "2rem",
          marginBottom: "2rem",
          flexWrap: "wrap",
        }}
      >
        <StatBlock value="10+" label="Sports Covered" />
        <StatBlock value="500+" label="Tutorials" />
        <StatBlock value="24/7" label="Support" />
        <StatBlock value="95%" label="User Success" />
      </div>

      {/* Video Section */}
      {showVideo && (
        <div
          style={{
            marginTop: "2rem",
            maxWidth: "768px", // Slightly smaller
            aspectRatio: "16 / 9",
            marginInline: "auto",
            position: "relative",
            borderRadius: "12px",
            overflow: "hidden",
            boxShadow: "0 0 20px rgba(0, 0, 0, 0.5)",
          }}
        >
          <iframe
            src="https://www.youtube.com/embed/YaXPRqUwItQ?autoplay=1&modestbranding=1&rel=0"
            title="Demo Video"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              border: "none",
            }}
          />
        </div>
      )}
    </section>
  );
};

// StatBlock component
const StatBlock = ({ value, label }) => (
  <div style={{ textAlign: "center" }}>
    <h3 style={{ color: "#38bdf8", fontSize: "1.5rem" }}>{value}</h3>
    <p>{label}</p>
  </div>
);

export default Hero; 
