import React, { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, Legend } from "chart.js";

ChartJS.register(ArcElement, ChartTooltip, Legend);

// Sample data
const weeklyStats = {
  Cricket: [
    { name: "Week 1", accuracy: 70 },
    { name: "Week 2", accuracy: 80 },
    { name: "Week 3", accuracy: 85 },
  ],
  Football: [
    { name: "Week 1", accuracy: 60 },
    { name: "Week 2", accuracy: 75 },
    { name: "Week 3", accuracy: 78 },
  ],
  Gym: [
    { name: "Week 1", accuracy: 65 },
    { name: "Week 2", accuracy: 70 },
    { name: "Week 3", accuracy: 75 },
  ],
};

const monthlyStats = {
  Cricket: [
    { name: "May", accuracy: 78 },
    { name: "June", accuracy: 88 },
    { name: "July", accuracy: 92 },
  ],
  Football: [
    { name: "May", accuracy: 65 },
    { name: "June", accuracy: 70 },
    { name: "July", accuracy: 80 },
  ],
  Gym: [
    { name: "May", accuracy: 68 },
    { name: "June", accuracy: 74 },
    { name: "July", accuracy: 83 },
  ],
};

const VisualDashboard = () => {
  const [selectedSport, setSelectedSport] = useState("Cricket");
  const [timeView, setTimeView] = useState("weekly");
  const [userInput, setUserInput] = useState("");
  const [customData, setCustomData] = useState([]);

  const activeData =
    timeView === "weekly"
      ? weeklyStats[selectedSport]
      : monthlyStats[selectedSport];

  const handleAddProgress = () => {
    if (userInput.trim()) {
      setCustomData([
        ...customData,
        { name: `Custom ${customData.length + 1}`, accuracy: parseInt(userInput) },
      ]);
      setUserInput("");
    }
  };

  const doughnutData = {
    labels: ["Good Form", "Needs Improvement"],
    datasets: [
      {
        data: [80, 20],
        backgroundColor: ["#5bc0be", "#3a506b"],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="page-container" style={{ padding: "2rem", color: "#fff" }}>
      <h1 style={{ color: "#5bc0be" }}>Visual Dashboard</h1>

      {/* Sport Tabs */}
      <div style={{ marginBottom: "1rem" }}>
        {["Cricket", "Football", "Gym"].map((sport) => (
          <button
            key={sport}
            onClick={() => setSelectedSport(sport)}
            style={{
              marginRight: "1rem",
              padding: "0.5rem 1rem",
              borderRadius: "6px",
              border: "none",
              backgroundColor:
                selectedSport === sport ? "#5bc0be" : "#3a506b",
              color: "#fff",
              cursor: "pointer",
            }}
          >
            {sport}
          </button>
        ))}
      </div>

      {/* Toggle Weekly/Monthly */}
      <div style={{ marginBottom: "1rem" }}>
        {["weekly", "monthly"].map((view) => (
          <button
            key={view}
            onClick={() => setTimeView(view)}
            style={{
              marginRight: "1rem",
              padding: "0.4rem 0.8rem",
              borderRadius: "6px",
              border: "1px solid #5bc0be",
              backgroundColor: timeView === view ? "#5bc0be" : "transparent",
              color: "#fff",
              cursor: "pointer",
            }}
          >
            {view.charAt(0).toUpperCase() + view.slice(1)}
          </button>
        ))}
      </div>

      {/* Bar Chart */}
      <div style={{ width: "100%", height: 300, marginBottom: "2rem" }}>
        <ResponsiveContainer>
          <BarChart
            data={[...activeData, ...customData]}
            margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#3a506b" />
            <XAxis dataKey="name" stroke="#ffffff" />
            <YAxis stroke="#ffffff" />
            <Tooltip />
            <Bar dataKey="accuracy" fill="#5bc0be" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Real-Time Input */}
      <div style={{ marginBottom: "2rem" }}>
        <h3>Add Custom Progress (%)</h3>
        <input
          type="number"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          style={{
            padding: "0.5rem",
            marginRight: "0.5rem",
            borderRadius: "4px",
            border: "1px solid #ccc",
            width: "100px",
          }}
        />
        <button
          onClick={handleAddProgress}
          style={{
            padding: "0.5rem 1rem",
            backgroundColor: "#5bc0be",
            color: "#fff",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
          }}
        >
          Add
        </button>
      </div>

      {/* Doughnut Chart */}
      <div style={{ width: "300px", margin: "0 auto" }}>
        <h3 style={{ textAlign: "center", marginBottom: "1rem" }}>
          AI Form Accuracy
        </h3>
        <Doughnut data={doughnutData} />
      </div>
    </div>
  );
};

export default VisualDashboard;
