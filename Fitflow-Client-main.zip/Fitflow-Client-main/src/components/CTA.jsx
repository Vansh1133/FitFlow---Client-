import React from "react";

const CTA = () => (
  <section className="cta-section">
    <div className="cta-content">
      <h2>Ready to Elevate Your Sports Performance?</h2>
      <p>Join thousands of athletes improving their form with us.</p>
      <button className="btn primary">Get Started Now</button>
    </div>
  </section>
);

export default CTA;
