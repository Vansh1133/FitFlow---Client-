import React from "react";

const FeedbackButton = () => {
  const handleFeedback = () => {
    const feedback = prompt("What would you like to see improved or added?");
    if (feedback) {
      alert("Thanks for your feedback! 💡 We'll review: " + feedback);
    }
  };

  return (
    <button className="feedback-btn" onClick={handleFeedback}>
      💬 Feedback
    </button>
  );
};

export default FeedbackButton;
