import React from "react";
import { Link } from "react-router-dom";

const FootballAvatar = () => {
  return (
    <section className="avatar-detail-page">
      <div className="container">
        <h2>Football Dribbling & Control Basics</h2>
        <p>Master fundamental football skills with this tutorial – ideal for beginners and aspiring players.</p>

        <div className="video-container">
          <iframe
            width="100%"
            height="480"
            src="https://www.youtube.com/embed/naEccnjzLxM"
            title="Football Dribbling Tutorial"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        <Link to="/" className="back-link">← Back to Home</Link>
      </div>
    </section>
  );
};

export default FootballAvatar;
