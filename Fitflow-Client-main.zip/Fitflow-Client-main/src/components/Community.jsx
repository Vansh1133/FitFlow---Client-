import React from "react";
import { Link } from "react-router-dom"; // ✅ Import Link

const Community = () => (
  <section className="community-section">
    <div className="community-content">
      <h2>Join Our Training Community</h2>
      <p>
        Connect with passionate athletes, expert trainers, and sport lovers. Ask
        questions, share tips, and improve together.
      </p>
      <div className="community-card">
        <i className="fas fa-comments icon"></i>
        <p>
          <strong>50K+</strong> Active Members
        </p>
        <p>Get instant feedback and tips from pros.</p>

        {/* ✅ Use Link to route to /community */}
        <Link to="/community" className="btn primary">
          Join Community
        </Link>
      </div>
    </div>
  </section>
);

export default Community;


// import React, { useState } from "react"; // Added useState
// import { Link } from "react-router-dom";

// const Community = () => {
//   const [postContent, setPostContent] = useState(''); // State for user input

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch('http://localhost:5000/posts', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({ content: postContent }),
//       });

//       if (response.ok) {
//         console.log('Post submitted successfully!');
//         setPostContent(''); // Clear input after submission
//       } else {
//         console.error('Failed to submit post');
//       }
//     } catch (error) {
//       console.error('Error submitting post:', error);
//     }
//   };

//   return (
//     <section className="community-section">
//       <div className="community-content">
//         <h2>Join Our Training Community</h2>
//         <p>
//           Connect with passionate athletes, expert trainers, and sport lovers. Ask
//           questions, share tips, and improve together.
//         </p>
//         <div className="community-card">
//           <i className="fas fa-comments icon"></i>
//           <p>
//             <strong>50K+</strong> Active Members
//           </p>
//           <p>Get instant feedback and tips from pros.</p>
          
//           {/* New Post Form */}
//           <form onSubmit={handleSubmit} className="post-form">
//             <textarea
//               value={postContent}
//               onChange={(e) => setPostContent(e.target.value)}
//               placeholder="Share your thoughts with the community..."
//               rows="3"
//               required
//             />
//             <button type="submit" className="btn primary">
//               Post Message
//             </button>
//           </form>
          
//           <Link to="/community" className="btn primary">
//             Join Community
//           </Link>
//         </div>
//       </div>
//     </section>
//   );
// };

// export default Community;
