import React from "react";
import { Link } from "react-router-dom";

const CricketAvatar = () => {
  return (
    <section className="avatar-detail-page">
      <div className="container">
        <h2>Cricket Batting Form Tutorial</h2>
        <p>Master the basics of a perfect batting stance and swing through this detailed video guide.</p>

        <div className="video-container">
          <iframe
            width="100%"
            height="480"
            src="https://www.youtube.com/embed/P43EHrx4LVM"
            title="Cricket Batting Tutorial"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        <Link to="/" className="back-link">← Back to Home</Link>
      </div>
    </section>
  );
};

export default CricketAvatar;
